#
# Author:: Julian C. Dunn (<jdunn@chef.io>)
# Cookbook:: vcruntime
# Attributes:: vc6
# Copyright:: 2014-2017, Chef Software, Inc.
# License:: Apache License, Version 2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


default['vcruntime']['vc8']['x86']['9.0.21022']['url'] = 'https://download.microsoft.com/download/1/1/1/1116b75a-9ec3-481a-a3c8-1777b5381140/vcredist_x86.exe'
default['vcruntime']['vc8']['x86']['9.0.21022']['sha256sum'] = 'c6a7e484f4d84883bc1205bccea3114c0521025712922298ede9b2a1cd632357'
default['vcruntime']['vc8']['x86']['9.0.21022']['name'] = 'Microsoft Visual C++ 2008 Redistributable (x86)'

#default['vcruntime']['vc8']['x64']['9.0.21022']['url'] = 'https://download.microsoft.com/download/d/2/4/d242c3fb-da5a-4542-ad66-f9661d0a8d19/vcredist_x64.exe'
#default['vcruntime']['vc8']['x64']['9.0.21022']['url'] = 'C:\vagrant\binaries\dotnet\Microsoft Visual C++ 2008 Redistributable - x64 9.0.21022\vcredist_x64.exe'
default['vcruntime']['vc8']['x64']['9.0.21022']['url'] = 'http://artifactory.devops.aig.net:8081/artifactory/aig-generic-local/tmp/chef/vcredist_x64_MicrosoftVisualC++2008Redistributable-x64%209.0.21022.exe'
default['vcruntime']['vc8']['x64']['9.0.21022']['sha256sum'] = 'baaaeddc17bcda8d20c0a82a9eb1247be06b509a820d65dda1342f4010bdb4a0'
default['vcruntime']['vc8']['x64']['9.0.21022']['name'] = 'Microsoft Visual C++ 2008 Redistributable (x64)'


default['vcruntime']['vc8']['x86']['9.0.30729']['url'] = 'https://download.microsoft.com/download/d/d/9/dd9a82d0-52ef-40db-8dab-795376989c03/vcredist_x86.exe'
default['vcruntime']['vc8']['x86']['9.0.30729']['sha256sum'] = '41f45a46ee56626ff2699d525bb56a3bb4718c5ca5f4fb5b3b38add64584026b'
default['vcruntime']['vc8']['x86']['9.0.30729']['name'] = 'Microsoft Visual C++ 2008 SP1 Redistributable (x86)'

#default['vcruntime']['vc8']['x64']['9.0.30729']['url'] = 'https://download.microsoft.com/download/2/d/6/2d61c766-107b-409d-8fba-c39e61ca08e8/vcredist_x64.exe'
#default['vcruntime']['vc8']['x64']['9.0.30729']['url'] = 'C:\vagrant\binaries\dotnet\Microsoft Visual C++ 2008 Redistributable - x64 9.0.30729.17\vcredist_x64.exe'
default['vcruntime']['vc8']['x64']['9.0.30729']['url'] = 'http://artifactory.devops.aig.net:8081/artifactory/aig-generic-local/tmp/chef/vcredist_MicrosoftVisualC++2008Redistributable-x64%209.0.30729.17.exe'
default['vcruntime']['vc8']['x64']['9.0.30729']['sha256sum'] = '55bf99ad3f063165c3ee1626787b5d4c2b65b5001fef79dd58c3490369ed282f'
default['vcruntime']['vc8']['x64']['9.0.30729']['name'] = 'Microsoft Visual C++ 2008 SP1 Redistributable (x64)'


#default['vcruntime']['vc8']['x64']['9.0.30729.6161']['url'] = 'C:\vagrant\binaries\dotnet\Microsoft Visual C++ 2008 Redistributable - x64 9.0.30729.6161\vcredist_x64.exe'
default['vcruntime']['vc8']['x64']['9.0.30729.6161']['url'] = 'http://artifactory.devops.aig.net:8081/artifactory/aig-generic-local/tmp/chef/vcredist_MicrosoftVisualC++2008Redistributable-x64%209.0.30729.6161.exe'
default['vcruntime']['vc8']['x64']['9.0.30729.6161']['sha256sum'] = 'b811f2c047a3e828517c234bd4aa4883e1ec591d88fad21289ae68a6915a6665'
default['vcruntime']['vc8']['x64']['9.0.30729.6161']['name'] = 'Microsoft Visual C++ 2008 SP1 Redistributable (x64)'