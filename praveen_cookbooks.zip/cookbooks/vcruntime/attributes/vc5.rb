#
# Author:: Julian C. Dunn (<jdunn@chef.io>)
# Cookbook:: vcruntime
# Attributes:: vc5
# Copyright:: 2014-2017, Chef Software, Inc.
# License:: Apache License, Version 2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#default['vcruntime']['vc5']['x86']['8.0.56336']['url']  = 'https://download.microsoft.com/download/e/1/c/e1c773de-73ba-494a-a5ba-f24906ecf088/vcredist_x86.exe'
default['vcruntime']['vc5']['x86']['8.0.56336']['url']  = 'C:\vagrant\binaries\dotnet\vcredist_x86.exe'
default['vcruntime']['vc5']['x86']['8.0.56336']['sha256sum'] = 'eb00f891919d4f894ab725b158459db8834470c382dc60cd3c3ee2c6de6da92c'
default['vcruntime']['vc5']['x86']['8.0.56336']['name']      = 'Microsoft Visual C++ 2005 Redistributable (X86)'

#default['vcruntime']['vc5']['x64']['8.0.56336']['url']  = 'https://download.microsoft.com/download/d/4/1/d41aca8a-faa5-49a7-a5f2-ea0aa4587da0/vcredist_x64.exe'
#default['vcruntime']['vc5']['x64']['8.0.56336']['url']  = 'C:\vagrant\binaries\dotnet\Microsoft Visual C++ 2005 Redistributable (x64)\vcredist_x64.exe'
default['vcruntime']['vc5']['x64']['8.0.56336']['url']  = 'http://artifactory.devops.aig.net:8081/artifactory/aig-generic-local/tmp/chef/vcredist_MicrosoftVisualC++2005Redistributablex64.exe'
default['vcruntime']['vc5']['x64']['8.0.56336']['sha256sum'] = '7ccbf7aff0d190db0831e5f22bb200adaa4cd5ec6e1147aaa19fe87627ef666f'
default['vcruntime']['vc5']['x64']['8.0.56336']['name']      = 'Microsoft Visual C++ 2005 Redistributable (X64)'

default['vcruntime']['vc5']['version'] = '8.0.56336'

