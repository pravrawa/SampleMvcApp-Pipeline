#
# Author:: Julian C. Dunn (<jdunn@chef.io>)
# Cookbook:: vcruntime
# Attributes:: vc12
# Copyright:: 2014-2017, Chef Software, Inc.
# License:: Apache License, Version 2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


#default['vcruntime']['vc12']['x86']['11.0.61030']['url'] = 'https://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU_4/vcredist_x86.exe'
#default['vcruntime']['vc12']['x86']['11.0.61030']['sha256sum'] = 'b924ad8062eaf4e70437c8be50fa612162795ff0839479546ce907ffa8d6e386'
#default['vcruntime']['vc12']['x86']['11.0.61030']['name'] = 'Microsoft Visual C++ 2012 x86'


#default['vcruntime']['vc12']['x64']['11.0.61030']['url'] = 'https://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU_4/vcredist_x64.exe'
#default['vcruntime']['vc12']['x64']['11.0.61030']['sha256sum'] = '681be3e5ba9fd3da02c09d7e565adfa078640ed66a0d58583efad2c1e3cc4064'
#default['vcruntime']['vc12']['x64']['11.0.61030']['name'] = 'Microsoft Visual C++ 2012 x64'

#default['vcruntime']['vc12']['version'] = '11.0.61030'
