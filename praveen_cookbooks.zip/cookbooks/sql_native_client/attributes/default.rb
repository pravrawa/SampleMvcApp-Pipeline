

#default['sql_server']['native_client']['url']               = 'http://download.microsoft.com/download/F/E/D/FEDB200F-DE2A-46D8-B661-D019DFE9D470/ENU/x64/sqlncli.msi'
default['sql_server']['native_client']['url']               = 'http://artifactory.devops.aig.net:8081/artifactory/aig-generic-local/tmp/chef/sqlncli_2012.msi'
    default['sql_server']['native_client']['checksum']          = '1364bf4c37a09ce3c87b029a2db4708f066074b1eaa22aa4e86d437b7b05203d'
    default['sql_server']['native_client']['package_name']      = 'Microsoft SQL Server 2012 Native Client'



default['sql_server']['accept_eula'] = false
default['sql_server']['product_key'] = nil
default['sql_server']['version'] = '2012'