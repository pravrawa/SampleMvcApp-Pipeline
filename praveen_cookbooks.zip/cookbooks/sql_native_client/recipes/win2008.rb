#
# Cookbook Name:: sql_native_client
# Recipe:: default
#
# Copyright (c) 2017 The Authors, All Rights Reserved.

::Chef::Recipe.send(:include, SQLClientInstallation)

node.default['sql_server']['version'] = '2008'

#node.default['sql_server']['native_client']['url']               = 'http://download.microsoft.com/download/F/7/B/F7B7A246-6B35-40E9-8509-72D2F8D63B80/sqlncli_amd64.msi'
node.default['sql_server']['native_client']['url']               = 'http://artifactory.devops.aig.net:8081/artifactory/aig-generic-local/tmp/chef/sqlncli_amd_2008_64.msi'
node.default['sql_server']['native_client']['checksum']          = '77cb222d4e573e0aafb3d0339c2018eec2b8d7335388d0a2738e1b776ab0b2be'
node.default['sql_server']['native_client']['package_name']      = 'Microsoft SQL Server 2008 R2 Native Client'
    
 
sqlClient
