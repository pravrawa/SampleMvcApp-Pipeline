#
# Cookbook Name:: sql_native_client
# Recipe:: default
#
# Copyright (c) 2017 The Authors, All Rights Reserved.

::Chef::Recipe.send(:include, SQLClientInstallation)

node.default['sql_server']['version'] = '2012'
sqlClient