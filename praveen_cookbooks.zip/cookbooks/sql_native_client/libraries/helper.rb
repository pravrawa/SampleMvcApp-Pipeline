#
# Author:: Seth Chisamore (<schisamo@chef.io>)
# Cookbook:: sql_server
# Library:: helper
#
# Copyright:: 2011-2016, Chef Software, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

require 'chef/mixin/shell_out'

module SqlClient
  class Helper
    extend Chef::Mixin::ShellOut

    
    def self.install_dir_version(version)
      case version.to_s # to_s to make sure someone didn't pass us an int
      when '2008' then '100'
      when '2012' then '110'
      when '2014' then '120'
      when '2016' then '130'
      else raise "SQL Server version #{version} not supported. Please open a PR to add support for this version."
      end
    end   

  end
end
