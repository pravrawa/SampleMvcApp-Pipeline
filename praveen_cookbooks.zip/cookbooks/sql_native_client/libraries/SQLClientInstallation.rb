

module SQLClientInstallation
 
 def  sqlClient
 


  package node['sql_server']['native_client']['package_name'] do
    source node['sql_server']['native_client']['url']
    checksum node['sql_server']['native_client']['checksum']
    installer_type :msi
    options "IACCEPTSQLNCLILICENSETERMS=#{node['sql_server']['accept_eula'] ? 'YES' : 'NO'}"
    action :install
  end

# update path
windows_path "#{node['sql_server']['install_dir']}\\#{SqlClient::Helper.install_dir_version(node['sql_server']['version'])}\\Tools\\Binn" do
  action :add
end

end
end

