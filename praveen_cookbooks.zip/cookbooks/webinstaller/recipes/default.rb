#
# Cookbook Name:: webinstaller
# Recipe:: default
#
# Copyright (c) 2017 The Authors, All Rights Reserved.

include_recipe "webinstaller::webinstaller_50"