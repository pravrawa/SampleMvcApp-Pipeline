windows_package node['webinstaller_50']['package_name'] do
  source node['webinstaller_50']['url']
  action :install
end