default['webinstaller_50']['package_name'] = 'Microsoft Web Platform Installer 5.0'
#default['webinstaller_50']['url'] = 'C:\vagrant\binaries\dotnet\Microsoft Web Platform Installer 5.0\WebPlatformInstaller_amd64_en-US.msi'
default['webinstaller_50']['url'] = 'http://artifactory.devops.aig.net:8081/artifactory/aig-generic-local/tmp/chef/WebPlatformInstaller_amd64_en-US_5_0.msi'