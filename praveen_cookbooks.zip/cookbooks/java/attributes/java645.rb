#default['java']['java645']['x86']['45']['url']  = 'C:\vagrant\binaries\dotnet\vcredist_x86.exe'
#default['java']['java645']['x86']['45']['sha256sum'] = 'eb00f891919d4f894ab725b158459db8834470c382dc60cd3c3ee2c6de6da92c'
#default['java']['java645']['x86']['45']['name']      = 'Java(TM) 6 Update 45 (64-bit)'

#default['java']['java645']['x64']['45']['url']  = 'C:\vagrant\binaries\dotnet\java\jre-6u45-windows-x64.exe'
default['java']['java645']['x64']['45']['url']  = 'http://artifactory.devops.aig.net:8081/artifactory/aig-generic-local/tmp/chef/jre-6u45-windows-x64.exe'
default['java']['java645']['x64']['45']['sha256sum'] = '16d5c9f0eb4e3fad207416ed1c98926be7a946f044ba8ad8e19de1242dff0c25'
default['java']['java645']['x86']['45']['name']      = 'Java(TM) 6 Update 45 (64-bit)'

default['java']['java645']['version'] = '45'

