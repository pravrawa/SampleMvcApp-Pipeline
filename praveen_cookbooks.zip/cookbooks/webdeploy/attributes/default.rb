default['webdeploy_35']['package_name'] = 'Web Deploy 3.5'
#default['webdeploy_35']['url'] = 'C:\vagrant\binaries\dotnet\Microsoft Web Deploy 3.5\WebDeploy_amd64_en-US.msi'
default['webdeploy_35']['url'] = 'http://artifactory.devops.aig.net:8081/artifactory/aig-generic-local/tmp/chef/WebDeploy_3_5_amd64_en-US.msi'

default['webdeploy_20']['package_name'] = 'Web Deploy 2.0'
#default['webdeploy_20']['url'] = 'C:\vagrant\binaries\dotnet\Microsoft Web Deploy 2.0\WebDeploy_2_10_amd64_en-US.msi'
default['webdeploy_20']['url'] = 'http://artifactory.devops.aig.net:8081/artifactory/aig-generic-local/tmp/chef/WebDeploy_2_10_amd64_en-US.msi'