windows_package node['webdeploy_35']['package_name'] do
  source node['webdeploy_35']['url']
  action :install
end