windows_package node['webdeploy_20']['package_name'] do
  source node['webdeploy_20']['url']
  action :install
end