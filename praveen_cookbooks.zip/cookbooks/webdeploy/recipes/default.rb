#
# Cookbook Name:: webdeploy
# Recipe:: default
#
# Copyright (c) 2017 The Authors, All Rights Reserved.

include_recipe "webdeploy::webdeploy_20"
include_recipe "webdeploy::webdeploy_35"