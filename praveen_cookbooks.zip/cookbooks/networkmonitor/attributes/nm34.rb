#default['networkmonitor']['nm34']['x86']['3.4']['url']  = 'https://download.microsoft.com/download/e/1/c/e1c773de-73ba-494a-a5ba-f24906ecf088/vcredist_x86.exe'
#default['networkmonitor']['nm34']['x86']['3.4']['url']  = 'C:\vagrant\binaries\dotnet\vcredist_x86.exe'
#default['networkmonitor']['nm34']['x86']['3.4']['sha256sum'] = 'eb00f891919d4f894ab725b158459db8834470c382dc60cd3c3ee2c6de6da92c'
default['networkmonitor']['nm34']['x86']['3.4']['name']      = 'Microsoft Network Monitor 3.4'

#default['networkmonitor']['nm34']['x64']['3.4']['url']  = 'https://download.microsoft.com/download/d/4/1/d41aca8a-faa5-49a7-a5f2-ea0aa4587da0/vcredist_x64.exe'
#default['networkmonitor']['nm34']['x64']['3.4']['url']  = 'C:\vagrant\binaries\dotnet\java\jre-6u45-windows-x64.exe'
default['networkmonitor']['nm34']['x64']['3.4']['url']  = 'http://artifactory.devops.aig.net:8081/artifactory/aig-generic-local/tmp/chef/NM34_x64.exe'
default['networkmonitor']['nm34']['x64']['3.4']['sha256sum'] = 'ab0b46acc1439077d801356fc5ac5af5f05349db249e87f1afede9e69edf7cf6'
default['networkmonitor']['nm34']['x86']['3.4']['name']      = 'Microsoft Network Monitor 3.4'

default['networkmonitor']['nm34']['version'] = '3.4'

